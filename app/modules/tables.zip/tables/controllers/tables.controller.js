(function () {
  'use strict';

  angular.module('pb.ds.tables').controller('TablesController', function ($log) {
    // var _this = this;
  });
})();
